import '../../components/404';

const NotFound = {
  async render() {
    return '<not-found></not-found>';
  },
};

export default NotFound;
