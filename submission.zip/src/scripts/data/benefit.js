const benefits = [
  {
    id: 1,
    img: 'icon-eat.svg',
    title: 'come and eat',
    text: 'Get your own table quickly & without waiting in line',
  },
  {
    id: 2,
    img: 'icon-fee.svg',
    title: 'No Extra Fee',
    text: 'Get tax free if you want to order food and make a reservation',
  },
  {
    id: 3,
    img: 'icon-clean.svg',
    title: 'Guaranteed Cleanliness',
    text: 'We ensure the cleanliness of the place as well as the foode',
  },
  {
    id: 4,
    img: 'icon-discount.svg',
    title: 'Extra Discounts',
    text: 'Get your special discount by using our reservation',
  },
];

export default benefits;
